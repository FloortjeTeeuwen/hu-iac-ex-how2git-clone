# IAC Project
When you clone this repository and publish it to your own repository, make sure it's private.

Do not use this project as a template for new projects. It is poor by design and it is used to illustrate principles and techniques on how we should properly organize code.
